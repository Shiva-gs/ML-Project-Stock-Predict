# Import dependencies






import numpy as np
from flask import (
    Flask,
    render_template,
    jsonify)
from joblib import load
import sklearn.datasets 
from io import BytesIO

import pandas as pd
from flask import Flask, send_file

# Set up Flask
app = Flask(__name__)


# home route
@app.route("/")
def index():
    """Renders homepage"""
    return render_template("index.html")

@app.route("/industry")
def industry():
    """Renders requirements page"""
    return render_template("industry.html")

@app.route("/linear")
def linear():
    """Renders requirements page"""
    return render_template("linear.html")

@app.route('/plot')
def plot():
    import numpy as np 
    import pandas as pd
    from sklearn.linear_model import LinearRegression
    from sklearn.svm import SVR
    from sklearn.model_selection import train_test_split
    import pandas_datareader.data as web
    from datetime import datetime

    
    now_time = datetime.now()
    start_time = datetime(now_time.year - 25, now_time.month , now_time.day)
    now_time
    start_time

    stock_df = web.DataReader('AAPL','yahoo', start_time, now_time)
    
    start_time = datetime(now_time.year - 5, now_time.month , now_time.day)

    sp_df=web.DataReader('^GSPC','yahoo', start_time, now_time)

    df = stock_df[['Adj Close']]
    #Take a look at the new data

    forecast_out = 30
    df['Prediction'] = df[['Adj Close']].shift(-forecast_out)

    # Convert the dataframe to a numpy array
    X = np.array(df.drop(['Prediction'],1))

    #Remove the last 'n' rows
    X = X[:-forecast_out]

    ## Create the dependent data set (y)  #####
    # Convert the dataframe to a numpy array (All of the values including the NaN's)
    y = np.array(df['Prediction'])
    # Get all of the y values except the last 'n' rows
    y = y[:-forecast_out]

    # Split the data into 80% training and 20% testing
    x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.5)

    # Create and train the Support Vector Machine (Regressor)
    svr_rbf = SVR(kernel='rbf', C=1e3, gamma=0.1)
    svr_rbf.fit(x_train, y_train)

    # Testing Model: Score returns the coefficient of determination R^2 of the prediction. 
    # The best possible score is 1.0
    svm_confidence = svr_rbf.score(x_test, y_test)
    print("svm confidence: ", svm_confidence)

    # Create and train the Linear Regression  Model
    lr = LinearRegression()
    # Train the model
    lr.fit(x_train, y_train)

    # Testing Model: Score returns the coefficient of determination R^2 of the prediction. 
    # The best possible score is 1.0
    lr_confidence = lr.score(x_test, y_test)
    print("lr confidence: ", lr_confidence)

    # Set x_forecast equal to the last 30 rows of the original data set from Adj. Close column
    x_forecast = np.array(df.drop(['Prediction'],1))[-forecast_out:]

        # Create and train the Linear Regression  Model
    lr = LinearRegression()
    # Train the model
    lr.fit(x_train, y_train)

    # Print linear regression model predictions for the next 'n' days
    lr_prediction = lr.predict(x_forecast)
    print(lr_prediction)
    lr_pdf=pd.DataFrame(lr_prediction)
    lr_pdf

    #Error 
    from sklearn.metrics import mean_squared_error,r2_score
    #df['InitialPrediction'] = df[['Adj Close']].shift()
    Y_orginal= np.array(df.drop(['Prediction'],1))
    Y_true=Y_orginal[-30:]
    Y_pred=lr_prediction
    #mean_squared_error(Y_orginal[-30:], lr_prediction)
    MSE = np.square(np.subtract(Y_true,Y_pred)).mean() 
    MSE 

    rmse=r2_score(Y_true, Y_pred)
    rmse

    # Print support vector regressor model predictions for the next 'n' days
    svm_prediction = svr_rbf.predict(x_forecast)

    dt=datetime.today().strftime('%Y-%m-%d')

    df.tail(30) 
    new_df= df.tail(30) 
    new_df['Prediction']=lr_prediction

    import matplotlib.pyplot as plt
    import seaborn as sns
    plt.style.use('seaborn-darkgrid')
    
    plt.rc('figure', figsize=(20, 10))
    # create a color palette
    plt.style.use('seaborn-whitegrid')
    fig = plt.figure()
    ax = plt.axes()
    x = new_df.index
    labels=x.strftime("%b-%d")
    ax.plot(x.strftime("%b-%d"), new_df['Adj Close']);
    ax.plot(x.strftime("%b-%d"), new_df['Prediction']); 
    plt.xticks(x.strftime("%b-%d"), labels, rotation='vertical')

    plot = df.plot()
    stream = BytesIO()
    plot.figure.savefig(stream)
    stream.seek(0)
    return send_file(stream, mimetype='image/png')

    app.run(debug=True, port=8000)

if __name__ == "__main__":
    app.run(debug=False, port=8000, host="localhost", threaded=True)
